<?php
require_once 'config/database.php';

// Cek apakah session biodata ada
if(!isset($_SESSION['biodata'])) {
    header('Location: biodata.php');
    exit;
}

// Validasi semua jawaban kuesioner
$required = ['q1','q2','q3','q4','q5','q6','q7','q8','q9'];
foreach($required as $q) {
    if(!isset($_POST[$q]) || $_POST[$q] === "") {
        header('Location: kuesioner.php');
        exit;
    }
}

$biodata = $_SESSION['biodata'];
$saran = $_POST['saran'] ?? '';

try {
    $sql = "INSERT INTO survey_responses (nama, jenis_kelamin, usia, wa, pendidikan, pekerjaan, kecamatan, layanan, tahun, q1, q2, q3, q4, q5, q6, q7, q8, q9, saran) 
            VALUES (:nama, :jk, :usia, :wa, :pendidikan, :pekerjaan, :kecamatan, :layanan, :tahun, :q1, :q2, :q3, :q4, :q5, :q6, :q7, :q8, :q9, :saran)";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':nama' => $biodata['nama'],
        ':jk' => $biodata['jk'],
        ':usia' => $biodata['usia'],
        ':wa' => $biodata['wa'],
        ':pendidikan' => $biodata['pendidikan'],
        ':pekerjaan' => $biodata['pekerjaan'],
        ':kecamatan' => $biodata['kecamatan'],
        ':layanan' => $biodata['layanan'],
        ':tahun' => date('Y'),
        ':q1' => $_POST['q1'],
        ':q2' => $_POST['q2'],
        ':q3' => $_POST['q3'],
        ':q4' => $_POST['q4'],
        ':q5' => $_POST['q5'],
        ':q6' => $_POST['q6'],
        ':q7' => $_POST['q7'],
        ':q8' => $_POST['q8'],
        ':q9' => $_POST['q9'],
        ':saran' => $saran
    ]);
    
    // Hapus session biodata setelah sukses
    unset($_SESSION['biodata']);
    
    // Redirect ke halaman terima kasih
    header('Location: thanks.php?nama=' . urlencode($biodata['nama']));
    exit;
    
} catch(PDOException $e) {
    die("Gagal menyimpan data: " . $e->getMessage());
}
?>